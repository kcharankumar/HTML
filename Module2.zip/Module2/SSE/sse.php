<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
echo "data: The server is alive\n\n";
flush();
?>