<?php

$con=mysqli_connect("localhost","root","","trialdb");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
if((isset($_POST['name']))&&(isset($_POST['pwd']))&&(isset($_POST['mail'])))
{
	$name=$_REQUEST['name'];
	$password=$_REQUEST['pwd'];
	$email=$_REQUEST['mail'];
	$msg="Hi";
	$gender="Female";
	$skill1="yes";
	


	$sql="INSERT INTO trialtable (name, password, email,msg,gender,skill)
	VALUES ('$name','$password','$email','$msg','$gender','$skill1')";

	if (!mysqli_query($con,$sql)) {
	  die('Error: ' . mysqli_error($con));
	}
	echo "1 record added";

}
//header("Location:next.php");
mysqli_close($con);
?>