<?php

$con=mysqli_connect("localhost","root","","trialdb");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
if((isset($_POST['name']))&&(isset($_POST['pwd']))&&(isset($_POST['mail']))&&(isset($_POST['msg']))&&(isset($_POST['sex'])))
{
	$name=$_REQUEST['name'];
	$password=$_REQUEST['pwd'];
	$email=$_REQUEST['mail'];
	$msg=$_REQUEST['msg'];
	$gender=$_REQUEST['sex'];
	if(isset($_POST['skill11']))
	{
		$skill1="yes";
	}
	else
	{
		$skill1="no";
	}


	$sql="INSERT INTO table3 (name, password, email,msg,gender,skill)
	VALUES ('$name','$password','$email','$msg','$gender','$skill1')";

	if (!mysqli_query($con,$sql)) {
	  die('Error: ' . mysqli_error($con));
	}
	echo "1 record added";

}
header("Location:next.php");
mysqli_close($con);
?>