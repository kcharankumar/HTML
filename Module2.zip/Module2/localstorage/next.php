<html>
   <head>
      <style>
		.textbox
		{
			height:25px;
			width:240px;
			-moz-border-radius:7px; /* Firefox */
			-webkit-border-radius: 7px; /* Safari, Chrome */
			-khtml-border-radius: 7px; /* KHTML */
			border-radius: 7px; /* CSS3 */
		}
		td,label
		{
			padding:20px;
		}
		
		.btn
		{
			cursor:pointer; /*forces the cursor to change to a hand when the button is hovered*/
			padding:5px 25px; /*add some padding to the inside of the button*/
			background:#0450ab; /*the colour of the button*/
			border:1px solid #0bc0ef; /*required or the default border for the browser will appear*/
			/*give the button curved corners, alter the size as required*/
			-moz-border-radius: 10px;
			-webkit-border-radius: 10px;
			border-radius: 10px;
			/*give the button a drop shadow*/
			-webkit-box-shadow: 0 0 4px rgba(0,0,0, .75);
			-moz-box-shadow: 0 0 4px rgba(0,0,0, .75);
			box-shadow: 0 0 4px rgba(0,0,0, .75);
			/*style the text*/
			color:#f3f3f3;
			font-size:1.1em;
		}
		.btn:hover, .btn:focus
		{
			background-color :#012045; /*make the background a little darker*/
			/*reduce the drop shadow size to give a pushed button effect*/
			-webkit-box-shadow: 0 0 1px rgba(0,0,0, .75);
			-moz-box-shadow: 0 0 1px rgba(0,0,0, .75);
			box-shadow: 0 0 1px rgba(0,0,0, .75);
		}
		
      </style>
   </head>
   <body>
      <form action="cd.php" method="post">
         <table style="height:100%;width:100%;background-color: #dddddd;">
            <tr >
               <td style="height:100%;width:30%">
               </td>
               <td style="height:100%;width:40%">
                  <table style="width:100%;background-color: #ffffff;box-shadow: 2px 2px 10px 10px  #888888;">
                     <tr>
                        <th colspan="2">
                          <h2> Registration form Part 2 </h2>
						  
						  <h6 style="color:#bbbbbb;margin:0px;padding:0px">Aadhar Card registration portal</h6>
						  <hr/>
                        </th>
                     </tr>
                     <tr>
                        <td>
                           <label for="name">Country(select)</label>
                        </td>
                        <td>
                           <select name="country" class="textbox">
								<option value="India">India</option>
								<option value="USA">USA</option>
								<option value="UK">UK</option>
								<option value="China">China</option>
								<option value="Japan">Japan</option>
							</select>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <label for="mail">State(datalist)</label>
                        </td>
                        <td>
						  <input list="state" name="state" class="textbox">
							<datalist id="state">
							  <option value="Karnataka">
							  <option value="Rajasthan">
							  <option value="Maharastra">
							  <option value="Punjab">
							  <option value="Hariyana">
							   <option value="Tamilnadu">
							</datalist> 
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <label for="mail">Age(Number)</label>
                        </td>
                        <td>
                           <input type="number" name="age"
   min="0" max="100" step="10" value="30" class="textbox" />
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <label for="msg">Birthday:</label>
                        </td>
                        <td>
                           <input type="date" name="bday" class="textbox"/>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <label for="msg">Telephone/Mobile:</label>
                        </td>
                        <td>
                           <input type="tel" name="usrtel" class="textbox"/>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <label for="msg">Skills:</label>
                        </td>
                        <td>
                           <input type="checkbox" name="skill11" value="C">C<br/>
                           <input type="checkbox" name="skill2" value="Java">Java<br/>
                           <input type="checkbox" name="skill3" value="Hadoop">Hadoop<br/>
                           <input type="checkbox" name="skill4" value="Storm">Storm 
                        </td>
                     </tr>
                     <tr>
						 <td>
						 </td>
                        <td ><input type="submit" value="Next" class="btn" onclick="location.href = 'next.php';" style="float:right;">
                        </td>
                     </tr>
                  </table>
               </td>
               <td style="height:100%;width:30%">
               </td>
            </tr>
         </table>
      </form>
   </body>
</html>