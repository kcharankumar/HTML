<?php

$con=mysqli_connect("localhost","root","","trialdb");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
if((isset($_POST['country']))&&(isset($_POST['state']))&&(isset($_POST['age']))&&(isset($_POST['bday']))&&(isset($_POST['usrtel'])))
{
	$country=$_REQUEST['country'];
	$state=$_REQUEST['state'];
	$age=$_REQUEST['age'];
	$bday=$_REQUEST['bday'];
	$gender=$_REQUEST['usrtel'];
	if(isset($_POST['skill11']))
	{
		$skill1="yes";
	}
	else
	{
		$skill1="no";
	}


	$sql="INSERT INTO table2 (country, state, age,bday,usrtel,skill)
	VALUES ('$country','$state','$age','$bday','$usrtel','$skill1')";

	if (!mysqli_query($con,$sql)) {
	  die('Error: ' . mysqli_error($con));
	}
	echo "1 record added";

}
header("Location:next.php");
mysqli_close($con);
?>