var i = 0;

function bigLoop() {
    i = i + 1;
    postMessage(i);
    setTimeout("bigLoop()",500);
}

bigLoop();